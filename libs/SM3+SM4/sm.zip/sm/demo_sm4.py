# -*-coding:utf-8-*-
from SM4 import *
from common import *
sm4 = SM4(key='0123456789abcdeffedcba9876543210') 
message = '0123456789abcdeffedcba9876543210' 
print '待加密数据: ', message 
print '密钥: ', sm4.__str__() 
C = sm4.sm4_encrypt(message_padding(message, SM4_PAD_PBOC), SM4_ECB) 
C2 = sm4.sm4_encrypt(message, SM4_ECB) 
print '密文: ', C ,C2
M = sm4.sm4_decrypt(C, SM4_ECB) 
print "mingwen",M