# -*-coding:utf-8-*-
from SM3 import calcu
res = calcu("abcd"*16)
print "###",res